$(function() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, 'test', function(data) {
            if (data === false) {
                $('#err').show();
            } else {
                $('input#erase').prop('checked', data.erase);
                $('input#extra').prop('checked', data.extra);
                $('textarea').text(data.users.join('\n'));
                $('#app').show();
            }
        })

        $('#app button').click(function() {
            chrome.tabs.sendMessage(tabs[0].id, {
                'users': $('textarea').val().split('\n'),
                'extra': $('input#extra').prop('checked'),
                'erase': $('input#erase').prop('checked'),
            });
            window.close();
        })
    })
})
