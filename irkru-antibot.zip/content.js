const pattern = new RegExp('https://www.irk.ru(/users/.+/)$');

var bans = new Set();
var conf = {};
var gist = 'https://gist.githubusercontent.com/sn3girok/d0f23dc24a92546cfede053b56a4f500/raw/36080536a1e9f33828ce1af4790357f3a75f393b/gistfile1.txt'

fetch(chrome.runtime.getURL('settings.json'))
.then((resp) => resp.json())
.then((data) => conf = data)
.then(() => fetch(gist))
.then((resp) => resp.text())
.then((data) => base = data.split('\n'))
.then(function() {
    chrome.storage.sync.get(Object.keys(conf), function(memory) {
        if ($.isEmptyObject(memory)) {
            chrome.storage.sync.set(conf);
        } else {
            conf = memory;
        }

        const handle = function($node) {
            if ($node.is('.j-comments-container, .j-comment-answers')) {
                var list = conf.users;
                if (conf.extra) {
                    list = [].concat(conf.users, base);
                }
                
                new Set(list).forEach(function(link) {
                    var user = link.match(pattern);
                    if (user) {
                        bans.add(link);
                        $node.find(`a[href="${user[1]}"].list-comments__username`).each(function() {
                            $(this).css('border', '1px solid black');
                            $(this).css('padding', '2px');

                            var $el = $(this).closest('li');
                            var $msg = $el.find('.j-comment-text:first');

                            $msg.css('color', 'black');
                            if ($msg.attr('data-text')) {
                                $msg.text($msg.attr('data-text'));
                            }

                            if (conf.erase) {
                                if ($el.closest('ul').hasClass('j-comments-list')) {
                                    $msg.attr('data-text', $msg.text());
                                    $msg.text('-');
                                } else {
                                    $el.hide();    
                                }
                            } else {
                                $el.show();
                                $msg.css('color', 'white');
                            }
                        })
                    }
                })
            }
        }

        const callback = function(record) {
            if (record[0].addedNodes.length && $(record[0].addedNodes[0]).hasClass('j-comments-preloader')) {
                return
            }

            record.forEach(function(item) {
                handle($(item.target));
            })
        }

        chrome.runtime.onMessage.addListener(function(message, sender, callback) {
            switch(message) {
                case 'test':
                if (new RegExp('irk.ru').test(location.href)) {
                    callback(conf);
                    return true;
                } else {
                    callback(false);
                }

                break

                default:
                chrome.storage.sync.set(message);
                conf = message;

                var $node = $('.lenta-material__comments > section');
                bans.forEach(function(link) {
                    if (conf.users.indexOf(link) == -1) {
                        var user = link.match(pattern);
                        bans.delete(link);
                        $node.find(`a[href="${user[1]}"].list-comments__username`).each(function() {
                            $(this).css('border', 'none');
                            $(this).css('padding', '0px');

                            var $el = $(this).closest('li');
                            var $msg = $el.find('.j-comment-text:first');

                            $el.show();
                            $msg.css('color', 'black');
                            $msg.text($msg.attr('data-text'));
                        })
                    }
                })

                handle($node);
            }
        })

        const observer = new MutationObserver(callback);
        observer.observe(document.querySelector('.lenta-material__comments'), {
            attributes: false,
            subtree: true,
            childList: true,
        });
    })
})
